# Chapter 7
## JRPG - Second to Last Fantasy Online (Game Server Code)
![Screenshot](../screenshots/node-logo-light.png)

TThis is the Game Server part covered in chapter 7. There is also a test page `index.html` that allows you to sumulate players interacting with the server.

This source code is open-sourced under the Apache License, Version 2.0 and is available on [GitHub](http://bit.ly/L8eFzj).
