function Stock(symbol, quantity) {
	this.symbol = symbol;
	this.price = 0.00;
	this.quantity = quantity;
}

module.exports = Stock;
